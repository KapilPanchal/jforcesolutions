package com.appjforce.serverjforce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerJforceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerJforceApplication.class, args);
	}

}
