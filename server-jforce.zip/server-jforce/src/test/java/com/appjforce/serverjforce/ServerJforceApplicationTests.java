package com.appjforce.serverjforce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerJforceApplicationTests {

	@Test
	void contextLoads() {
	}

}
