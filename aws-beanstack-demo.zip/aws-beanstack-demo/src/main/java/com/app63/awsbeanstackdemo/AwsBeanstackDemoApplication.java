package com.app63.awsbeanstackdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsBeanstackDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsBeanstackDemoApplication.class, args);
	}

}
