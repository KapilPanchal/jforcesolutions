package com.app63.awsbeanstackdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsBeanstackDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
